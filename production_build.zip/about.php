<?php
include 'includes/header.php';
?>

<section class="hero" style="height: 40vh; background-image: none; background-color: var(--primary-color);">
    <div class="hero-content">
        <h1>About Us</h1>
        <p>Our Legacy of Glass Craftsmanship</p>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="mb-5">
                    <h3>Our Story</h3>
                    <p>Shivhare Bangle Store has been a cornerstone in the wholesale bangle market of Firozabad, the city of bangles. For decades, we have been dedicated to preserving the traditional art of glass bangle making while innovating with modern designs and techniques.</p>
                    <p>Our journey began with a simple vision: to provide high-quality, durable, and beautiful glass bangles to retailers and wholesalers across India. Today, we are proud to be one of the trusted names in the industry.</p>
                </div>

                <div class="mb-5">
                    <h3>Why Choose Us?</h3>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item bg-transparent"><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Authenticity:</strong> 100% genuine Firozabad glass.</li>
                        <li class="list-group-item bg-transparent"><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Variety:</strong> An extensive catalog ranging from bridal sets to daily wear.</li>
                        <li class="list-group-item bg-transparent"><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Wholesale Focus:</strong> Competitive pricing structures designed for business growth.</li>
                        <li class="list-group-item bg-transparent"><i class="bi bi-check-circle-fill text-success me-2"></i> <strong>Reliability:</strong> Timely delivery and secure packaging for bulk orders.</li>
                    </ul>
                </div>

                <div>
                    <h3>Meet the Owner</h3>
                    <p>Under the visionary leadership of our founder, we have expanded our reach and maintained strong relationships with our partners. We believe in transparency and mutual growth.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
